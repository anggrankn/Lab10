package ru.vsu.cs;

import java.util.Date;

public class Project {
    public String name;
    public Date start;
    public Date end;

    public void getIntermediateResult(){

    }

    public void addToProject(){

    }

    public void beginProject(){

    }

    public void finishProject(){

    }
}
