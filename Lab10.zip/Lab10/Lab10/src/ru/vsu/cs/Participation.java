package ru.vsu.cs;

public class Participation {
    public int hours;
}
