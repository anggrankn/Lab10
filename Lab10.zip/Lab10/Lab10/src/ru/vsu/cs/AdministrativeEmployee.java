package ru.vsu.cs;

public class AdministrativeEmployee extends Employee {
}
