package ru.vsu.cs;

public class ResearchAssociate extends Employee {
    public String fieldOfStudy;

}
